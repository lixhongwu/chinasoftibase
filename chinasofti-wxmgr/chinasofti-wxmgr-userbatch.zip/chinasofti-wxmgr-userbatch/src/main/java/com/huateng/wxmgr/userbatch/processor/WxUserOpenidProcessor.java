package com.huateng.wxmgr.userbatch.processor;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Component;

import com.huateng.wxmgr.common.entity.WxUserOpenId;

@Component("wxUserOpenidProcessor")
public class WxUserOpenidProcessor implements ItemProcessor<WxUserOpenId, List<String>> {

	private final static Logger logger = LoggerFactory.getLogger(WxUserOpenidProcessor.class);

	@Override
	public List<String> process(WxUserOpenId item) throws Exception {
		logger.info(">>>>>>>>>>>WxUserOpenidProcessor {}", item.toString());
		return item.getOpenidList();
	}

}
