package com.huateng.wxmgr.userbatch.reader;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.huateng.wxmgr.common.entity.WxUserOpenId;
import com.huateng.wxmgr.userbatch.service.UserService;

@Component
public class WxUserOpenidReader implements ItemReader<WxUserOpenId> {

	@Autowired
	private UserService userService;

	private String nextOpenId;

	@Override
	public WxUserOpenId read()
			throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {

		if (nextOpenId.isEmpty()) {
			nextOpenId = "";
		}
		WxUserOpenId usersOpenId = userService.getUsersOpenId(nextOpenId);
		this.nextOpenId= usersOpenId.getNext_openid();

		return usersOpenId;
	}

}
