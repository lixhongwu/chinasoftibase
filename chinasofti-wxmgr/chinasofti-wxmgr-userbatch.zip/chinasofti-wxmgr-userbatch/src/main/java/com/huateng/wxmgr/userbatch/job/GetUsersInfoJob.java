package com.huateng.wxmgr.userbatch.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.huateng.wxmgr.userbatch.service.AccessTokenService;

public class GetUsersInfoJob {

	private final static Logger logger = LoggerFactory.getLogger(GetUsersInfoJob.class);
	private static ApplicationContext context;

	public static void main(String[] args) {

		context = new ClassPathXmlApplicationContext("config/UserBatch.xml");

		AccessTokenService accessTokenService = context.getBean(AccessTokenService.class);
		String accessToken = accessTokenService.getAccessToken();

		logger.info("GetUsersInfoJob>>>>>>>>> {} ",accessToken);

	}

}
