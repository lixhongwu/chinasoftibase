package com.huateng.wxmgr.userbatch;

//@SpringBootApplication
public class UserBatchApplication {
	
	
	
	
	
	
}
